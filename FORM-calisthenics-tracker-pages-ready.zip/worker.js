export default {
  async fetch(request, env) {
    if (env.ASSETS?.fetch) return env.ASSETS.fetch(request);
    return new Response('FORM is ready.', {
      headers: { 'content-type': 'text/plain; charset=UTF-8' }
    });
  }
};
