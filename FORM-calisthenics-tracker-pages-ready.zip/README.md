# FORM — private calisthenics tracker

A polished, mobile-first React tracker for bodyweight training. It includes set completion, skill paths, calendar history, weight/waist charts, daily Apple Health summaries, and local-first persistence.

## Run locally

```bash
npm install
npm run dev
```

Production build:

```bash
npm run build
```

## Privacy model

The web app stores workout history and measurements in browser `localStorage`; there is no analytics or third-party data collection. The included iOS source reads only the HealthKit categories the user approves. For cross-device sync, connect the companion's `syncEndpoint` to an authenticated HTTPS endpoint that validates its bearer token and stores data under the signed-in user's account.

Apple does not let a website read HealthKit directly. The native iOS companion is therefore required for live Apple Health data.

## iOS companion

The `ios-companion/` folder contains the HealthKit service and SwiftUI screen. In Xcode:

1. Create a new iOS App target named `FormCompanion` (iOS 17+).
2. Add the two Swift files to the target.
3. Add the HealthKit capability under **Signing & Capabilities**.
4. Add `NSHealthShareUsageDescription` to `Info.plist`, explaining that FORM reads selected health data to show it in the user's private dashboard.
5. Replace `https://example.com/api/healthkit` and the placeholder token with an authenticated HTTPS endpoint and securely stored token (Keychain in production).

The companion requests read access for workouts, steps, Apple exercise time, active energy, heart rate, walking/running distance, and body mass. It sends aggregated daily values and workout summaries; it does not write to HealthKit.
