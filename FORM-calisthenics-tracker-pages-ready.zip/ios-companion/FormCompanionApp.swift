import SwiftUI

@main
struct FormCompanionApp: App {
    var body: some Scene { WindowGroup { ContentView() } }
}

struct ContentView: View {
    @StateObject private var health = HealthKitManager()
    // Replace these values during deployment. Store the token in Keychain in production.
    private let syncEndpoint = URL(string: "https://example.com/api/healthkit")!
    private let token = "replace-with-secure-user-token"

    var body: some View {
        NavigationStack {
            VStack(spacing: 24) {
                Image(systemName: "heart.text.square.fill")
                    .font(.system(size: 64)).foregroundStyle(.red)
                Text("FORM Health Sync").font(.title.bold())
                Text("Only the Health categories you approve are read. FORM sends daily summaries to your private dashboard and never writes to Apple Health.")
                    .foregroundStyle(.secondary).multilineTextAlignment(.center)
                if !health.isAuthorized {
                    Button("Choose Health permissions") { Task { await health.requestAuthorization() } }
                        .buttonStyle(.borderedProminent)
                } else {
                    Button(health.isSyncing ? "Syncing…" : "Sync now") {
                        Task { await health.sync(to: syncEndpoint, bearerToken: token) }
                    }.buttonStyle(.borderedProminent).disabled(health.isSyncing)
                }
                if let date = health.lastSync { Text("Last synced \(date.formatted())").font(.caption) }
                if let error = health.errorMessage { Text(error).foregroundStyle(.red).font(.caption) }
                Spacer()
            }.padding(28).navigationTitle("HealthKit")
        }
    }
}
