import Foundation
import HealthKit

struct HealthSyncPayload: Codable {
    let generatedAt: Date
    let day: String
    let steps: Double
    let exerciseMinutes: Double
    let activeEnergyKcal: Double
    let latestHeartRateBpm: Double?
    let distanceKilometres: Double
    let latestBodyMassPounds: Double?
    let workouts: [WorkoutSummary]
}

struct WorkoutSummary: Codable {
    let id: String
    let activityType: UInt
    let startedAt: Date
    let endedAt: Date
    let durationSeconds: Double
    let activeEnergyKcal: Double?
    let distanceKilometres: Double?
}

@MainActor
final class HealthKitManager: ObservableObject {
    @Published var isAuthorized = false
    @Published var isSyncing = false
    @Published var lastSync: Date?
    @Published var errorMessage: String?

    private let store = HKHealthStore()

    private var readTypes: Set<HKObjectType> {
        let ids: [HKQuantityTypeIdentifier] = [
            .stepCount, .appleExerciseTime, .activeEnergyBurned,
            .heartRate, .distanceWalkingRunning, .bodyMass
        ]
        return Set(ids.compactMap { HKObjectType.quantityType(forIdentifier: $0) })
            .union([HKObjectType.workoutType()])
    }

    func requestAuthorization() async {
        guard HKHealthStore.isHealthDataAvailable() else {
            errorMessage = "Health data is not available on this device."
            return
        }
        do {
            try await store.requestAuthorization(toShare: [], read: readTypes)
            isAuthorized = true
        } catch { errorMessage = error.localizedDescription }
    }

    func sync(to endpoint: URL, bearerToken: String) async {
        isSyncing = true
        defer { isSyncing = false }
        do {
            let payload = try await makeTodayPayload()
            var request = URLRequest(url: endpoint)
            request.httpMethod = "POST"
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
            request.setValue("Bearer \(bearerToken)", forHTTPHeaderField: "Authorization")
            request.httpBody = try JSONEncoder.iso8601.encode(payload)
            let (_, response) = try await URLSession.shared.data(for: request)
            guard let http = response as? HTTPURLResponse, 200..<300 ~= http.statusCode else {
                throw URLError(.badServerResponse)
            }
            lastSync = Date()
        } catch { errorMessage = error.localizedDescription }
    }

    private func makeTodayPayload() async throws -> HealthSyncPayload {
        let start = Calendar.current.startOfDay(for: Date())
        async let steps = cumulative(.stepCount, unit: .count(), since: start)
        async let exercise = cumulative(.appleExerciseTime, unit: .minute(), since: start)
        async let energy = cumulative(.activeEnergyBurned, unit: .kilocalorie(), since: start)
        async let distance = cumulative(.distanceWalkingRunning, unit: .meterUnit(with: .kilo), since: start)
        async let heart = latest(.heartRate, unit: HKUnit.count().unitDivided(by: .minute()))
        async let mass = latest(.bodyMass, unit: .pound())
        async let workouts = workoutSummaries(since: start)
        return try await HealthSyncPayload(
            generatedAt: Date(), day: ISO8601DateFormatter.day.string(from: start),
            steps: steps, exerciseMinutes: exercise, activeEnergyKcal: energy,
            latestHeartRateBpm: heart, distanceKilometres: distance,
            latestBodyMassPounds: mass, workouts: workouts
        )
    }

    private func cumulative(_ id: HKQuantityTypeIdentifier, unit: HKUnit, since start: Date) async throws -> Double {
        guard let type = HKQuantityType.quantityType(forIdentifier: id) else { return 0 }
        let predicate = HKQuery.predicateForSamples(withStart: start, end: Date(), options: .strictStartDate)
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKStatisticsQuery(quantityType: type, quantitySamplePredicate: predicate, options: .cumulativeSum) { _, result, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: result?.sumQuantity()?.doubleValue(for: unit) ?? 0) }
            }
            store.execute(query)
        }
    }

    private func latest(_ id: HKQuantityTypeIdentifier, unit: HKUnit) async throws -> Double? {
        guard let type = HKQuantityType.quantityType(forIdentifier: id) else { return nil }
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKSampleQuery(sampleType: type, predicate: nil, limit: 1,
                sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierEndDate, ascending: false)]) { _, samples, error in
                if let error { continuation.resume(throwing: error) }
                else { continuation.resume(returning: (samples?.first as? HKQuantitySample)?.quantity.doubleValue(for: unit)) }
            }
            store.execute(query)
        }
    }

    private func workoutSummaries(since start: Date) async throws -> [WorkoutSummary] {
        let predicate = HKQuery.predicateForSamples(withStart: start, end: Date(), options: .strictStartDate)
        return try await withCheckedThrowingContinuation { continuation in
            let query = HKSampleQuery(sampleType: .workoutType(), predicate: predicate, limit: HKObjectQueryNoLimit,
                sortDescriptors: [NSSortDescriptor(key: HKSampleSortIdentifierStartDate, ascending: false)]) { _, samples, error in
                if let error { continuation.resume(throwing: error); return }
                let values = (samples as? [HKWorkout] ?? []).map { w in
                    WorkoutSummary(id: w.uuid.uuidString, activityType: w.workoutActivityType.rawValue,
                        startedAt: w.startDate, endedAt: w.endDate, durationSeconds: w.duration,
                        activeEnergyKcal: w.totalEnergyBurned?.doubleValue(for: .kilocalorie()),
                        distanceKilometres: w.totalDistance?.doubleValue(for: .meterUnit(with: .kilo)))
                }
                continuation.resume(returning: values)
            }
            store.execute(query)
        }
    }
}

private extension JSONEncoder {
    static var iso8601: JSONEncoder { let value = JSONEncoder(); value.dateEncodingStrategy = .iso8601; return value }
}

private extension ISO8601DateFormatter {
    static var day: ISO8601DateFormatter { let value = ISO8601DateFormatter(); value.formatOptions = [.withFullDate]; return value }
}
